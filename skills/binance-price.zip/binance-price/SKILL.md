---
name: binance-price
description: Get real-time cryptocurrency prices from Binance API via web fetch (no CLI tools required).
homepage: https://binance.com
metadata: {"clawdbot":{"emoji":"📈"}}
---

# Binance Price

Fetch live crypto prices directly from the Binance public REST API – no API key, no CLI tools needed.

## API URLs (direkt im Browser oder via Web-Fetch aufrufbar)

### Einzelner Preis
```
https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT
```

### 24h Stats (High, Low, Volume, Change)
```
https://api.binance.com/api/v3/ticker/24hr?symbol=BTCUSDT
```

### Alle Preise auf einmal
```
https://api.binance.com/api/v3/ticker/price
```

## Antwort-Format

`/ticker/price` gibt zurück:
```json
{
  "symbol": "BTCUSDT",
  "price": "103421.50000000"
}
```

`/ticker/24hr` gibt zurück:
```json
{
  "symbol": "BTCUSDT",
  "lastPrice": "103421.50",
  "priceChangePercent": "2.35",
  "highPrice": "104800.00",
  "lowPrice": "101200.00",
  "volume": "18423.12"
}
```

## Symbol-Format

Immer **Großbuchstaben**, kein Schrägstrich:
- BTC/USDT → `BTCUSDT`
- ETH/USDT → `ETHUSDT`
- SOL/BTC  → `SOLBTC`

## Hinweise

- Kein API-Key erforderlich für Marktdaten
- Rate Limit: 1200 Requests/Minute
- Basis-URL: `https://api.binance.com`
