---
name: kilocli-coding-agent
description: Use this skill whenever the user wants to use Kilo CLI (also called "kilo" or "kilocode") to build apps, fix bugs, review pull requests, automate coding tasks, or run an AI agent on their codebase. Trigger even when the user doesn't say "Kilo CLI" explicitly — phrases like "let kilo handle it", "run the agent on this", "automate this coding task", "fix these issues in parallel", or "review my PRs automatically" should all trigger this skill. Always consult this skill before writing code yourself if the user has indicated they want to use Kilo CLI.
version: 1.0.0
metadata: {"requires":{"env":["GITHUB_TOKEN"],"bins":["kilo","git","gh","tmux"]},"primaryEnv":"GITHUB_TOKEN"}
---

# Kilo CLI Coding Agent

Kilo CLI is an open-source, model-agnostic AI coding agent for the terminal. It reads your code, writes files, runs shell commands, and completes entire coding tasks autonomously — with support for 500+ AI models from any provider.

---

## Step 0: Installation & Setup

```bash
# Install globally
npm install -g @kilocode/cli

# Or run directly without installing
npx @kilocode/cli

# Launch — authenticates via your Kilo account or API key
kilo

# Or configure a provider directly (e.g. Anthropic)
export ANTHROPIC_API_KEY="your-key-here"
# Kilo supports OpenAI, Google, Mistral, Llama and 500+ others too
```

**Model freedom:** Unlike other agents, Kilo isn't tied to one provider. Switch between Claude, GPT-4, Gemini, Llama, and 500+ others without changing tools.

---

## The Two Modes

### Interactive mode (default)
Type `kilo` to open a session. Kilo asks for approval before writing files or running commands — good for exploratory work.

### Autonomous mode (`--auto`)
Pass `--auto` with a prompt — Kilo runs fully without user interaction and exits when done. Perfect for CI/CD and background tasks:
```bash
kilo --auto "Explain what this codebase does"

# Resume the last session
kilo --continue   # or: kilo -c
```

---

## The Approval Problem — and How to Solve It

By default, Kilo asks for approval before every file write and shell command. For longer tasks this slows things down.

**`--auto` flag** — runs fully autonomously, no prompts:
```bash
kilo --auto "Build a REST API with Express and add tests"
```

⚠️ `--auto` disables all permission prompts. Only use it in trusted environments. Operations not configured for auto-approval will be blocked entirely.

**Granular permissions** — safer alternative, configure per tool in `opencode.json`:
```json
{
  "permission": {
    "bash": "ask",
    "edit": "allow",
    "read": "allow",
    "external_directory": {
      "~/projects/personal/**": "allow"
    }
  }
}
```

---

## Agent Modes — Choose the Right One

Kilo ships with five built-in modes, each optimized for different tasks:

| Mode | Best for |
|---|---|
| **Code** (default) | Writing, editing, refactoring code |
| **Architect** | Planning file structures, system design |
| **Debug** | Inspecting runtime errors, proposing and applying fixes |
| **Ask** | Lightweight Q&A, no file changes |
| **Orchestrator** | Chaining multiple agents for complex multi-step workflows |

```bash
# Switch mode inside a session
/mode architect

# Or start in a specific mode
kilo --mode debug --auto "Find and fix the memory leak in src/server.ts"
```

---

## Memory Bank — Persistent Project Context

Kilo uses a **Memory Bank** — structured markdown files in `.kilocode/rules/memory-bank/` that persist across sessions. Kilo reads them automatically at the start of every task:

```
.kilocode/rules/memory-bank/
├── context.md    # Stack, architecture, conventions
├── brief.md      # Active goals and current tasks
└── history.md    # Past decisions and constraints
```

Example `context.md`:
```markdown
This is a Next.js 14 app using TypeScript and Tailwind CSS.
Package manager: pnpm
Testing: Vitest + Testing Library
After every change, run: pnpm test
Never modify files in the generated/ folder.
```

This saves repeating project context in every prompt — like CLAUDE.md or GEMINI.md but more structured.

---

## Referencing Files in Prompts

Use `@` to point Kilo at specific files:
```bash
kilo --auto "Review @src/auth.ts for security issues"
kilo --auto "Write tests for @src/api/users.js"

# Attach an image to a prompt (useful for UI bug reports)
kilo --auto "Fix the layout issue" --attach screenshot.png
```

---

## Custom Commands — Reusable Workflows

Create `.md` files in `.kilocode/` to define reusable slash commands:

```markdown
<!-- .kilocode/fix-issue.md -->
---
description: Fix a GitHub issue and open a PR
mode: code
---
Fix issue #$ARGUMENTS following our coding standards.
Run pnpm test. Only commit if tests pass.
Then create a PR with gh pr create.
```

Use it in a session:
```
> /fix-issue 42
```

---

## Structured Output for Scripting

When you need to parse Kilo's output in a script:

```bash
# JSON output (requires --auto)
kilo --auto --json "List all functions in src/ with no tests"

# Bidirectional JSON via stdin/stdout (for programmatic control)
echo '{"type":"newTask","text":"Fix the bug in auth.ts"}' | kilo --json-io

# Auto-generate commit messages from staged changes
git diff --cached | kilo --auto --json "Write a concise commit message" \
  | jq -r '.text' | git commit -F -
```

---

## Autonomous Building & Creating

```bash
# Fully autonomous — no prompts
bash workdir:~/project background:true command:"kilo --auto \"Build a snake game with dark theme. Add keyboard controls and a score counter.\""

# Returns sessionId — monitor with:
process action:log sessionId:XXX       # see what Kilo is doing
process action:poll sessionId:XXX      # check if finished
process action:write sessionId:XXX data:"y"   # answer a question if asked
process action:kill sessionId:XXX      # stop if needed
process action:list                    # see all running sessions
```

**Why background mode?** Autonomous builds can take 5–20 minutes. Background mode lets you do other things while Kilo works.

---

## Error Handling

### If Kilo seems stuck
```bash
# Check logs first — maybe it's just working on something large
process action:log sessionId:XXX

# If truly stuck after 10+ minutes, kill and retry with clearer instructions
process action:kill sessionId:XXX
bash workdir:~/project background:true command:"kilo --auto \"Fix issue #42. Previous attempt failed with: <paste error>. Try approach X instead.\""
```

### Save logs before they're gone
```bash
process action:log sessionId:XXX > /tmp/kilo-run-$(date +%s).log
```

### Resume interrupted sessions
```bash
kilo --continue                  # resume last session
kilo --session <sessionId>       # restore a specific session
kilo --fork <sessionId>          # fork a session to try a different approach
```

---

## PR Reviews

**⚠️ Never review PRs in a live/running project folder — always use a clone or worktree.**

```bash
# Safest: clone to a temp folder
REVIEW_DIR=$(mktemp -d)
git clone https://github.com/org/repo.git $REVIEW_DIR
cd $REVIEW_DIR && gh pr checkout 42

bash workdir:$REVIEW_DIR background:true command:"kilo --auto \"Review the current branch vs main. Focus on: correctness, security, edge cases, code style. Include specific line numbers.\""

# Get the review and post to GitHub
process action:log sessionId:XXX
gh pr comment 42 --body "<review content>"

# Clean up
rm -rf $REVIEW_DIR
```

```bash
# Faster: git worktree (no full clone needed)
git worktree add /tmp/pr-42-review origin/pr-branch-name
bash workdir:/tmp/pr-42-review background:true command:"kilo --auto \"Review this branch vs main\""
# Cleanup:
git worktree remove /tmp/pr-42-review
```

### Batch PR Reviews (parallel)

```bash
# Fetch all PR refs
git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'

# Launch one Kilo per PR
bash workdir:~/project background:true command:"kilo --auto \"Review PR #10. Run: git diff origin/main...origin/pr/10\""
bash workdir:~/project background:true command:"kilo --auto \"Review PR #11. Run: git diff origin/main...origin/pr/11\""
bash workdir:~/project background:true command:"kilo --auto \"Review PR #12. Run: git diff origin/main...origin/pr/12\""

# Monitor all
process action:list

# Post reviews to GitHub
process action:log sessionId:AAA
gh pr comment 10 --body "<review content>"
```

---

## Parallel Issue Fixing (worktrees + tmux)

For fixing multiple GitHub issues simultaneously — each in its own isolated branch:

```bash
# 1. Clone to a temp folder (never use your main working directory)
cd /tmp && git clone git@github.com:user/repo.git repo-fixes
cd repo-fixes

# 2. Create isolated branches per issue
git worktree add -b fix/issue-78 /tmp/issue-78 main
git worktree add -b fix/issue-99 /tmp/issue-99 main

# 3. Set up tmux (Kilo CLI needs a real terminal — tmux provides that)
SOCKET="${TMPDIR:-/tmp}/kilo-fixes.sock"
tmux -S "$SOCKET" new-session -d -s fix-78
tmux -S "$SOCKET" new-session -d -s fix-99

# 4. Launch Kilo in each session
tmux -S "$SOCKET" send-keys -t fix-78 \
  "cd /tmp/issue-78 && npm install && kilo --auto 'Fix issue #78: <description>. Run npm test. Only commit if tests pass.'" Enter

tmux -S "$SOCKET" send-keys -t fix-99 \
  "cd /tmp/issue-99 && npm install && kilo --auto 'Fix issue #99: <description>. Run npm test. Only commit if tests pass.'" Enter

# 5. Monitor progress
tmux -S "$SOCKET" capture-pane -p -t fix-78 -S -30
tmux -S "$SOCKET" capture-pane -p -t fix-99 -S -30

# Check if done
tmux -S "$SOCKET" capture-pane -p -t fix-78 -S -3 | grep -q "❯" && echo "fix-78 done!"

# 6. Push and create PRs
cd /tmp/issue-78 && git push -u origin fix/issue-78
gh pr create --repo user/repo --head fix/issue-78 \
  --title "fix: resolve issue #78" \
  --body "Fixes #78. Automated fix via Kilo CLI."

# 7. Always clean up
tmux -S "$SOCKET" kill-server
git -C /tmp/repo-fixes worktree remove /tmp/issue-78
git -C /tmp/repo-fixes worktree remove /tmp/issue-99
rm -rf /tmp/repo-fixes
```

---

## Model Selection

One of Kilo's biggest advantages — switch models freely per task:

```bash
kilo --model anthropic/claude-opus-4-6 --auto "Redesign the database schema"
kilo --model openai/gpt-4o --auto "Fix the bug in auth.ts"
kilo --model google/gemini-2.5-pro --auto "Analyze the architecture"
```

Or set a default in `opencode.json`:
```json
{
  "model": "anthropic/claude-sonnet-4-6",
  "provider": "anthropic"
}
```

---

## Notifications When Long Tasks Finish

```bash
# macOS
process action:poll sessionId:XXX && \
  osascript -e 'display notification "Kilo done!" with title "Agent done"'

# Linux (requires libnotify: sudo apt install libnotify-bin)
process action:poll sessionId:XXX && \
  notify-send "Agent done" "Kilo finished!"

# Windows (PowerShell)
# while (-not (process action:poll sessionId:XXX)) { Start-Sleep 5 }
# [System.Windows.Forms.MessageBox]::Show("Kilo finished!")

# Cross-platform: terminal bell
process action:poll sessionId:XXX && echo -e "\a"

# Cross-platform: log to file (always works)
process action:poll sessionId:XXX && echo "Done at $(date)" >> /tmp/kilo-done.log
```

---

## MCP Servers (Advanced)

Connect Kilo to external tools — GitHub, Slack, databases, and more. Configure in `opencode.json`:

```json
{
  "mcp": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": { "GITHUB_TOKEN": "$GITHUB_TOKEN" }
    }
  }
}
```

Then Kilo can call GitHub directly in a session:
```
> List my open pull requests on org/repo
> Create a PR from the current branch
```

---

## Safety Rules

1. **Never work in live/running app folders** — use `/tmp` or git worktrees
2. **Never checkout branches in a running project** — clone or use worktrees
3. **Respect user tool choice** — if they want Kilo, use Kilo; don't offer to code it yourself
4. **Check logs before killing** — a slow session is usually just working hard
5. **Always clean up** — remove temp dirs, worktrees, and tmux sessions when done
6. **Use Memory Bank** — put project context in `.kilocode/rules/memory-bank/` so every session starts informed
7. **`--auto` with care** — it runs shell commands without asking; use granular `opencode.json` permissions for a safer middle ground
8. **Never start Kilo in `~/openclaw/`** — it'll read soul docs and get confused about the org chart
