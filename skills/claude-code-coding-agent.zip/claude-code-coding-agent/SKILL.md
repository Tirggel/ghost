---
name: claude-code-coding-agent
description: Use this skill whenever the user wants to use Claude Code (also called "claude", "CC", or "claude-code") to build apps, fix bugs, review pull requests, automate coding tasks, or run an AI agent on their codebase. Trigger even when the user doesn't say "Claude Code" explicitly — phrases like "let claude handle it", "run the agent on this", "automate this coding task", "fix these issues in parallel", or "review my PRs automatically" should all trigger this skill. Always consult this skill before writing code yourself if the user has indicated they want to use Claude Code.
version: 1.0.0
metadata: {"requires":{"bins":["claude","git","gh","tmux"]}}
---

# Claude Code Coding Agent

Claude Code is Anthropic's open-source AI coding agent for the terminal. It reads your codebase, writes files, runs shell commands, manages git workflows, and completes entire tasks autonomously — all from a prompt in your terminal.

---

## Step 0: Installation & Setup

```bash
# Install globally
npm install -g @anthropic-ai/claude-code

# Launch — authenticates via your Claude.ai account or API key
claude

# Or set API key directly
export ANTHROPIC_API_KEY="your-key-here"
```

**Requirements:** Claude Pro, Max, or API access. The free Claude.ai plan does not include terminal access.

---

## The Two Modes

### Interactive mode (default)
Type `claude` to open a session. Claude asks for approval before writing files or running commands.

### Non-interactive / headless mode (`-p`)
Pass a prompt directly — Claude runs once and exits. Perfect for scripts and background tasks:
```bash
claude -p "Explain what this codebase does"

# Continue the last session
claude -c
```

---

## The Approval Problem — and How to Solve It

By default, Claude asks before every file write and shell command. For longer tasks this slows things down.

**`--dangerously-skip-permissions`** — skips all approval prompts:
```bash
claude --dangerously-skip-permissions "Build a REST API with Express and add tests"
```
⚠️ Only use this when you trust the task. Claude will write files and run shell commands without asking.

**Granular permissions** — safer alternative, allow only specific tools:
```bash
# Allow only git commands and test runner
claude --allowedTools "Read" "Grep" "Bash(git *)" "Bash(npm test:*)" "Write"

# Or set per-project in .claude/settings.json:
```
```json
{
  "permissions": {
    "allow": ["Read", "Write", "Bash(git *)", "Bash(npm *)"],
    "deny": ["Read(./.env)", "Read(./secrets/**)", "Bash(curl:*)"]
  }
}
```

---

## CLAUDE.md — Give Claude Persistent Context

Create a `CLAUDE.md` in your project root. Claude reads it automatically every session.
There's also a global one at `~/.claude/CLAUDE.md` that applies to all projects:

```markdown
# CLAUDE.md
This is a Next.js 14 app using TypeScript and Tailwind CSS.
Package manager: pnpm
Testing: Vitest + Testing Library
After every change run: pnpm test
Never modify files in the generated/ folder.
Commit messages must follow Conventional Commits.
```

Initialize one automatically by running `/init` inside a Claude session — it scans your project and generates a starter file.

---

## Referencing Files in Prompts

Use `@` to reference specific files:
```bash
claude "Review @src/auth.ts for security issues"
claude "Write tests for @src/api/users.js"
```

Use `!` to run bash commands and inject their output:
```bash
claude "Here is the current diff: !git diff HEAD — what should I fix first?"
```

---

## Useful Slash Commands (inside a session)

| Command | What it does |
|---|---|
| `/init` | Scan project and create a starter CLAUDE.md |
| `/clear` | Clear conversation history (save tokens) |
| `/compact` | Summarize conversation to free up context window |
| `/permissions` | View and edit allowed tools interactively |
| `/tasks` | See background sessions and teleport into one |
| `/fast` | Toggle fast mode (Opus 4.6, up to 2.5x faster, costs more) |
| `/debug` | Show session debug info for troubleshooting |
| `/help` | Show all available commands including custom ones |

---

## Plan Mode — Think Before Acting

Plan Mode uses extended thinking to create a full strategy before writing a single line of code. Great for complex or risky tasks:

```bash
# Start in plan mode
claude --plan "Migrate the database schema from v1 to v2 without downtime"

# Or toggle inside a session:
/plan
```

Claude outlines the approach, you approve, then it executes. No surprises.

---

## Custom Commands (Reusable Workflows)

Create `.md` files in `.claude/commands/` (project) or `~/.claude/commands/` (personal) to define reusable slash commands:

```markdown
<!-- .claude/commands/fix-issue.md -->
---
allowed-tools: Bash(git *), Bash(npm test:*), Read, Write
description: Fix a GitHub issue and open a PR
---
Fix issue #$ARGUMENTS following our coding standards.
Run npm test. Only commit if tests pass.
Then create a PR with gh pr create.
```

Use it in a session:
```
> /fix-issue 42
```

---

## Autonomous Building & Creating

```bash
# Fully autonomous — skips all approvals
bash workdir:~/project background:true command:"claude --dangerously-skip-permissions -p \"Build a snake game with dark theme. Add keyboard controls and a score counter.\""

# Returns sessionId — monitor with:
process action:log sessionId:XXX       # see what Claude is doing
process action:poll sessionId:XXX      # check if finished
process action:write sessionId:XXX data:"y"   # answer a question if asked
process action:kill sessionId:XXX      # stop if needed
process action:list                    # see all running sessions
```

---

## Error Handling

### If Claude seems stuck
```bash
# Check logs first
process action:log sessionId:XXX

# If truly stuck after 10+ minutes, kill and retry with clearer prompt
process action:kill sessionId:XXX
bash workdir:~/project background:true command:"claude --dangerously-skip-permissions -p \"Fix issue #42. Previous attempt failed with: <error>. Try approach X instead.\""
```

### Save logs before they're gone
```bash
process action:log sessionId:XXX > /tmp/claude-run-$(date +%s).log
```

---

## PR Reviews

**⚠️ Never review PRs in a live/running project folder — always clone or use worktrees.**

```bash
# Safest: clone to a temp folder
REVIEW_DIR=$(mktemp -d)
git clone https://github.com/org/repo.git $REVIEW_DIR
cd $REVIEW_DIR && gh pr checkout 42

bash workdir:$REVIEW_DIR background:true command:"claude -p \"Review the current branch vs main. Focus on: correctness, security, edge cases, code style. Include specific line numbers.\""

# Get the review and post to GitHub
process action:log sessionId:XXX
gh pr comment 42 --body "<review content>"

# Clean up
rm -rf $REVIEW_DIR
```

```bash
# Faster: git worktree (no full clone needed)
git worktree add /tmp/pr-42-review origin/pr-branch-name
bash workdir:/tmp/pr-42-review background:true command:"claude -p \"Review this branch vs main\""
# Cleanup:
git worktree remove /tmp/pr-42-review
```

### Batch PR Reviews (parallel)

```bash
# Fetch all PR refs
git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'

# Launch one Claude per PR
bash workdir:~/project background:true command:"claude -p \"Review PR #10. Run: git diff origin/main...origin/pr/10\""
bash workdir:~/project background:true command:"claude -p \"Review PR #11. Run: git diff origin/main...origin/pr/11\""
bash workdir:~/project background:true command:"claude -p \"Review PR #12. Run: git diff origin/main...origin/pr/12\""

# Monitor all
process action:list

# Post reviews
process action:log sessionId:AAA
gh pr comment 10 --body "<review content>"
```

---

## Parallel Issue Fixing (worktrees + tmux)

```bash
# 1. Clone to temp folder
cd /tmp && git clone git@github.com:user/repo.git repo-fixes
cd repo-fixes

# 2. Create isolated branches per issue
git worktree add -b fix/issue-78 /tmp/issue-78 main
git worktree add -b fix/issue-99 /tmp/issue-99 main

# 3. Set up tmux (Claude Code needs a real terminal)
SOCKET="${TMPDIR:-/tmp}/claude-fixes.sock"
tmux -S "$SOCKET" new-session -d -s fix-78
tmux -S "$SOCKET" new-session -d -s fix-99

# 4. Launch Claude in each session
tmux -S "$SOCKET" send-keys -t fix-78 \
  "cd /tmp/issue-78 && npm install && claude --dangerously-skip-permissions -p 'Fix issue #78: <description>. Run npm test. Only commit if tests pass.'" Enter

tmux -S "$SOCKET" send-keys -t fix-99 \
  "cd /tmp/issue-99 && npm install && claude --dangerously-skip-permissions -p 'Fix issue #99: <description>. Run npm test. Only commit if tests pass.'" Enter

# 5. Monitor
tmux -S "$SOCKET" capture-pane -p -t fix-78 -S -30
tmux -S "$SOCKET" capture-pane -p -t fix-99 -S -30

# Check if done
tmux -S "$SOCKET" capture-pane -p -t fix-78 -S -3 | grep -q "❯" && echo "fix-78 done!"

# 6. Push and create PRs
cd /tmp/issue-78 && git push -u origin fix/issue-78
gh pr create --repo user/repo --head fix/issue-78 \
  --title "fix: resolve issue #78" \
  --body "Fixes #78."

# 7. Always clean up
tmux -S "$SOCKET" kill-server
git -C /tmp/repo-fixes worktree remove /tmp/issue-78
git -C /tmp/repo-fixes worktree remove /tmp/issue-99
rm -rf /tmp/repo-fixes
```

---

## Custom System Prompts

Override Claude's default behavior with a custom system prompt — useful for enforcing project standards, personas, or strict output formats:

```bash
# Inline system prompt
claude --system-prompt "You are a senior security engineer. Every response must include a threat model. Never suggest storing secrets in environment variables." \
  "Review src/auth.ts"

# From a file (better for longer prompts)
claude --system-prompt "$(cat .claude/security-reviewer.md)" "Review src/auth.ts"

# Append to the default system prompt instead of replacing it
claude --append-system-prompt "Always end your response with a checklist of things to verify manually." \
  "Refactor the payment module"
```

**Tip:** Combine with `--allowedTools` to create tightly scoped, safe agents:
```bash
claude \
  --system-prompt "You are a read-only code reviewer. Never write or modify files." \
  --allowedTools "Read" "Grep" "Glob" \
  -p "Review the entire src/ folder for security issues"
```

---

## Extended Thinking

Extended thinking makes Claude reason deeply before responding — ideal for architecture decisions, complex bugs, or anything where getting it right matters more than speed:

```bash
# Enable extended thinking explicitly
claude --extended-thinking "Design a database schema for a multi-tenant SaaS app"

# Combine with plan mode for maximum deliberation before any action
claude --plan --extended-thinking "Migrate the auth system from JWT to OAuth2 without breaking existing sessions"

# In an interactive session, toggle it:
/think
```

**When to use extended thinking:**
- Architecture or design decisions
- Debugging hard-to-reproduce issues
- Security-sensitive code changes
- Anything you'd otherwise spend hours researching yourself

**When NOT to use it:** Simple tasks like formatting, renaming, or writing boilerplate — it's slower and costs more tokens.

---

## Subagents (Parallel Specialized Agents)

Claude Code can spawn specialized subagents — each with its own tools, model, and system prompt. Claude orchestrates them automatically.

### General example
```bash
claude --agents '{
  "code-reviewer": {
    "description": "Expert code reviewer. Use after code changes.",
    "prompt": "You are a senior code reviewer. Focus on correctness, security, and best practices.",
    "tools": ["Read", "Grep", "Glob"],
    "model": "sonnet"
  },
  "test-writer": {
    "description": "Writes missing tests.",
    "prompt": "You write thorough unit and integration tests.",
    "tools": ["Read", "Write", "Bash(npm test:*)"],
    "model": "sonnet"
  }
}' "Review the auth module and add missing tests"
```

### PR Review with subagents
```bash
# One agent reads the diff, another checks security, another writes the comment
claude --agents '{
  "diff-reader": {
    "description": "Reads and summarizes the PR diff",
    "prompt": "Summarize what changed and why it matters.",
    "tools": ["Read", "Bash(git *)"],
    "model": "sonnet"
  },
  "security-checker": {
    "description": "Checks for security issues",
    "prompt": "You are a security expert. Find vulnerabilities, injection risks, and auth flaws.",
    "tools": ["Read", "Grep"],
    "model": "opus"
  },
  "comment-writer": {
    "description": "Writes the final GitHub PR comment",
    "prompt": "Write a clear, constructive PR review comment based on findings.",
    "tools": ["Bash(gh *)"],
    "model": "sonnet"
  }
}' "Review PR #42 and post the result as a GitHub comment"
```

### Parallel issue fixing with subagents
```bash
# Each subagent fixes one issue independently
claude --agents '{
  "fix-78": {
    "description": "Fixes issue #78",
    "prompt": "Fix issue #78: <description>. Run tests. Commit if green.",
    "tools": ["Read", "Write", "Bash(git *)", "Bash(npm test:*)"],
    "model": "sonnet"
  },
  "fix-99": {
    "description": "Fixes issue #99",
    "prompt": "Fix issue #99: <description>. Run tests. Commit if green.",
    "tools": ["Read", "Write", "Bash(git *)", "Bash(npm test:*)"],
    "model": "sonnet"
  }
}' "Fix both issues in parallel and open a PR for each"
```

**Note:** For subagent-based parallel fixing, each agent still needs its own worktree or branch to avoid conflicts. Claude handles the orchestration but not the git isolation — set that up first (see Parallel Issue Fixing section above).

---

## MCP Servers (Connect External Tools)

MCP extends Claude Code with direct access to GitHub, Slack, databases, and more:

```bash
# Add GitHub MCP server
claude mcp add --transport http github https://mcp.github.com

# Start with MCP debug
claude --mcp-debug
```

After installing GitHub MCP, Claude can call GitHub directly in sessions:
```
> List my open pull requests
> Create a PR from the current branch to main
```

---

## Model Selection

```bash
# Use Opus for complex reasoning / architecture
claude --model claude-opus-4-6 "Redesign the database schema"

# Use Sonnet (default) for most tasks
claude "Fix the bug in auth.ts"

# Use Haiku for fast/cheap simple tasks
claude --model claude-haiku-4-5-20251001 "Format this JSON file"

# Toggle fast mode mid-session (Opus 4.6, 2.5x faster, higher cost)
/fast
```

---

## Notifications When Long Tasks Finish

```bash
# macOS
process action:poll sessionId:XXX && \
  osascript -e 'display notification "Claude done!" with title "Agent done"'

# Linux (requires libnotify: sudo apt install libnotify-bin)
process action:poll sessionId:XXX && \
  notify-send "Agent done" "Claude finished!"

# Windows (PowerShell)
# while (-not (process action:poll sessionId:XXX)) { Start-Sleep 5 }
# [System.Windows.Forms.MessageBox]::Show("Claude finished!")

# Cross-platform: terminal bell
process action:poll sessionId:XXX && echo -e "\a"

# Cross-platform: log to file (always works)
process action:poll sessionId:XXX && echo "Done at $(date)" >> /tmp/claude-done.log
```

---

## Safety Rules

1. **Never work in live/running app folders** — use `/tmp` or git worktrees
2. **Never checkout branches in a running project** — clone or use worktrees
3. **Respect user tool choice** — if they want Claude Code, use it; don't offer to code it yourself
4. **Check logs before killing** — a slow session is usually just working hard
5. **Always clean up** — remove temp dirs, worktrees, and tmux sessions when done
6. **Use CLAUDE.md** — put project context there so every session starts informed
7. **`--dangerously-skip-permissions` with care** — it runs shell commands without asking; use `--allowedTools` for a safer middle ground
8. **Plan mode for risky tasks** — use `--plan` before executing anything destructive or hard to reverse
