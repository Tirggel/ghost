---
name: gemini-cli-coding-agent
description: Use this skill whenever the user wants to use Gemini CLI (also called "gemini") to build apps, fix bugs, review pull requests, automate code tasks, or run an AI agent on their codebase. Trigger even when the user doesn't say "Gemini CLI" explicitly — phrases like "let gemini do it", "use the google agent", "run this autonomously", "review my PRs automatically", or "fix these issues in parallel" should all trigger this skill. Always consult this skill before writing code yourself if the user has indicated they want to use Gemini CLI.
version: 1.0.0
metadata: {"requires":{"bins":["gemini","git","gh","tmux"]}}
---

# Gemini CLI Coding Agent

Gemini CLI is Google's open-source AI coding agent for the terminal. It can read your code, write files, run shell commands, and complete entire coding tasks autonomously — all from a simple prompt.

---

## Step 0: Installation & Setup

```bash
# Install globally
npm install -g @google/gemini-cli

# First launch — opens browser to authenticate with your Google account
gemini

# Alternative: use an API key (required for paid models or headless/CI use)
export GOOGLE_API_KEY="your-key-here"
```

**Free tier:** 60 requests/min, 1000 requests/day with a personal Google account. No credit card needed.

---

## The Two Modes

### Interactive mode (default)
Type `gemini` to open a chat-like session. Gemini asks for approval before writing files or running commands — good for exploratory work.

### Headless mode (for automation)
Pass a prompt directly with `-p` — Gemini runs once and exits. Perfect for scripts and background tasks:
```bash
gemini -p "Explain what this codebase does"
```

---

## The Approval Problem — and How to Solve It

By default, Gemini asks "Approve? (y/n)" before every file write and shell command. For longer tasks this gets tedious fast.

**`--yolo` flag** — auto-approves everything, no prompts:
```bash
gemini --yolo -p "Build a REST API with Express and add tests"
```

⚠️ Use `--yolo` only for tasks you trust. It will execute shell commands and write files without asking.

**`--auto-edit` flag** — only auto-approves file edits, still asks for shell commands (safer middle ground):
```bash
gemini --auto-edit -p "Refactor all components to use TypeScript"
```

---

## GEMINI.md — Give Gemini Persistent Context

Create a `GEMINI.md` file in your project root. Gemini reads it automatically every session:

```markdown
# GEMINI.md
This is a Next.js 14 app using TypeScript and Tailwind CSS.
Package manager: pnpm
Testing: Vitest + Testing Library
After every change, run: pnpm test
Never modify files in the generated/ folder.
```

This saves repeating project context in every prompt.

---

## Referencing Files in Prompts

Use `@` to point Gemini at specific files:
```bash
gemini -p "Review @src/auth.ts for security issues"
gemini -p "Write tests for @src/api/users.js"

# Or pipe content directly
cat src/auth.py | gemini -p "Review this for security issues"
```

---

## Checkpointing & Undo

Gemini automatically saves checkpoints before making changes. If something goes wrong in an interactive session:

```
/restore 0    # revert to before first change
/restore 1    # revert to checkpoint 1
```

This rolls back both file changes and conversation context.

---

## Autonomous Building & Creating

```bash
# Build something from scratch — fully autonomous
bash workdir:~/project background:true command:"gemini --yolo -p \"Build a snake game with dark theme. Add keyboard controls and a score counter.\""

# Returns sessionId — monitor with:
process action:log sessionId:XXX       # see what Gemini is doing
process action:poll sessionId:XXX      # check if finished
process action:write sessionId:XXX data:"y"   # answer a question if Gemini asks
process action:kill sessionId:XXX      # stop if needed
process action:list                    # see all running sessions
```

**Why background mode?** Autonomous builds can take 5–20 minutes. Background mode lets you do other things while Gemini works.

---

## Error Handling

### If Gemini seems stuck
```bash
# Check logs first — maybe it's just working on something large
process action:log sessionId:XXX

# If truly stuck after 10+ minutes, kill and retry with clearer instructions
process action:kill sessionId:XXX
bash workdir:~/project background:true command:"gemini --yolo -p \"Fix issue #42. Previous attempt failed with: <paste error>. Try approach X instead.\""
```

### Save logs before they're gone
```bash
process action:log sessionId:XXX > /tmp/gemini-run-$(date +%s).log
```

---

## PR Reviews

**⚠️ Never review PRs directly in a live/running project folder — always use a clone or worktree.**

```bash
# Safest: clone to a temp folder
REVIEW_DIR=$(mktemp -d)
git clone https://github.com/org/repo.git $REVIEW_DIR
cd $REVIEW_DIR && gh pr checkout 42

bash workdir:$REVIEW_DIR background:true command:"gemini -p \"Review the current branch vs main. Focus on: correctness, security, edge cases, code style. Be specific with line numbers.\""

# Get the review and post to GitHub
process action:log sessionId:XXX
gh pr comment 42 --body "<review content>"

# Clean up
rm -rf $REVIEW_DIR
```

```bash
# Faster alternative: git worktree (no full clone needed)
git worktree add /tmp/pr-42-review origin/pr-branch-name
bash workdir:/tmp/pr-42-review background:true command:"gemini -p \"Review this branch vs main\""
# Cleanup:
git worktree remove /tmp/pr-42-review
```

### Batch PR Reviews (multiple PRs in parallel)

```bash
# Fetch all PR refs at once
git fetch origin '+refs/pull/*/head:refs/remotes/origin/pr/*'

# Launch one Gemini per PR
# Free tier: max 3-4 parallel to avoid rate limits
bash workdir:~/project background:true command:"gemini -p \"Review PR #10. Run: git diff origin/main...origin/pr/10\""
bash workdir:~/project background:true command:"gemini -p \"Review PR #11. Run: git diff origin/main...origin/pr/11\""
bash workdir:~/project background:true command:"gemini -p \"Review PR #12. Run: git diff origin/main...origin/pr/12\""

# Check all sessions
process action:list

# Post reviews to GitHub
process action:log sessionId:AAA
gh pr comment 10 --body "<review content>"
```

---

## Parallel Issue Fixing

For fixing multiple GitHub issues simultaneously — each in its own isolated branch:

```bash
# 1. Clone to a temp folder (never use your main working directory)
cd /tmp && git clone git@github.com:user/repo.git repo-fixes
cd repo-fixes

# 2. Create isolated branches for each issue
git worktree add -b fix/issue-78 /tmp/issue-78 main
git worktree add -b fix/issue-99 /tmp/issue-99 main

# 3. Set up tmux (Gemini CLI needs a real terminal — tmux provides that)
SOCKET="${TMPDIR:-/tmp}/gemini-fixes.sock"
tmux -S "$SOCKET" new-session -d -s fix-78
tmux -S "$SOCKET" new-session -d -s fix-99

# 4. Launch Gemini in each session
# Include test instructions so Gemini verifies its own fix
tmux -S "$SOCKET" send-keys -t fix-78 \
  "cd /tmp/issue-78 && npm install && gemini --yolo -p 'Fix issue #78: <description>. Run npm test. Only commit if tests pass.'" Enter

tmux -S "$SOCKET" send-keys -t fix-99 \
  "cd /tmp/issue-99 && npm install && gemini --yolo -p 'Fix issue #99: <description>. Run npm test. Only commit if tests pass.'" Enter

# 5. Monitor progress
tmux -S "$SOCKET" capture-pane -p -t fix-78 -S -30   # last 30 lines
tmux -S "$SOCKET" capture-pane -p -t fix-99 -S -30

# Check if done (prompt symbol returned)
tmux -S "$SOCKET" capture-pane -p -t fix-78 -S -3 | grep -q "❯" && echo "fix-78 done!"

# 6. Push and create PRs
cd /tmp/issue-78 && git push -u origin fix/issue-78
gh pr create --repo user/repo --head fix/issue-78 \
  --title "fix: resolve issue #78" \
  --body "Fixes #78. Automated fix via Gemini CLI."

# 7. Always clean up
tmux -S "$SOCKET" kill-server
git -C /tmp/repo-fixes worktree remove /tmp/issue-78
git -C /tmp/repo-fixes worktree remove /tmp/issue-99
rm -rf /tmp/repo-fixes
```

---

## Structured Output for Scripting

When you need to parse Gemini's output in a script:

```bash
# Get JSON output and extract with jq
gemini --output-format json -p "List functions in src/ with no tests" | jq '.response'

# Auto-generate commit messages from staged changes
result=$(git diff --cached | gemini --output-format json -p "Write a concise commit message")
echo "$result" | jq -r '.response' | git commit -F -

# Track API usage / quota
gemini -p "Analyze logs" --session-summary /tmp/usage.json
```

---

## Notifications When Long Tasks Finish

```bash
# macOS
process action:poll sessionId:XXX && \
  osascript -e 'display notification "Gemini finished!" with title "Agent done"'

# Linux (requires libnotify: sudo apt install libnotify-bin)
process action:poll sessionId:XXX && \
  notify-send "Agent done" "Gemini finished!"

# Windows (PowerShell)
# Run in PowerShell, not bash:
# while (-not (process action:poll sessionId:XXX)) { Start-Sleep 5 }
# [System.Windows.Forms.MessageBox]::Show("Gemini finished!")

# Cross-platform: terminal bell (works everywhere)
process action:poll sessionId:XXX && echo -e "\a"

# Cross-platform: log to file (simplest, always works)
process action:poll sessionId:XXX && echo "Done at $(date)" >> /tmp/gemini-done.log
```

---

## Model & Rate Limit Tips

| Situation | What to do |
|---|---|
| Simple tasks, free tier | Default (Gemini Flash, auto-selected) |
| Complex reasoning / architecture | `gemini --model gemini-2.5-pro -p "..."` |
| Hitting rate limits | Max 3-4 parallel agents, or use a paid API key |
| CI/CD pipelines | Set `GOOGLE_API_KEY`, use `-p` headless mode |

---

## MCP Servers (Advanced)

Connect Gemini to external tools like GitHub, Slack, or databases via MCP. Configure in `~/.gemini/settings.json`:

```json
{
  "mcpServers": {
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"]
    }
  }
}
```

Then Gemini can call GitHub directly in a session:
```
> List my open pull requests on org/repo
> Create a PR from the current branch
```

---

## Safety Rules

1. **Never work in live/running app folders** — use `/tmp` or git worktrees
2. **Never checkout branches inside a running project** — clone or use worktrees
3. **Respect user tool choice** — if they want Gemini, use Gemini; don't offer to code it yourself
4. **Check logs before killing** — a "slow" session is usually just working hard
5. **Always clean up** — delete temp dirs, worktrees, and tmux sessions when done
6. **Watch free tier limits** — 1000 req/day goes fast with parallel agents; use `--session-summary` to track
7. **Use GEMINI.md** — put project context there so every session starts informed
8. **`--yolo` with care** — it runs shell commands automatically; use `--auto-edit` if you only want safe file edits
