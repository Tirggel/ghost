---
name: google-workspace
description: Universal Google Workspace Skill für Gmail, Calendar, Drive, Chat und Meet. Enthält Identitätsprüfung, Sicherheitsregeln und API-Anleitung für alle Google-Dienste. Wird bei JEDER Google-bezogenen Anfrage geladen.
metadata: {"clawdbot":{"emoji":"🔷"}}
---

# Google Workspace – Universal Skill

Dieser Skill gilt für ALLE Google-Dienste:
Gmail · Calendar · Drive · Chat · Meet · Contacts · Tasks

---

## 1. IDENTITÄT – Wird immer zuerst geladen

### ⚠️ Kritische Regel
Du darfst NIEMALS eine E-Mail-Adresse erfinden, annehmen oder ableiten.
Verwende AUSSCHLIESSLICH die Daten aus `/home/prubin/.flutterclaw/flutterclaw.json`.

### Datei laden
```
/home/prubin/.flutterclaw/flutterclaw.json → integrations
```

### Feldmapping
| JSON-Feld | Verwendung |
|---|---|
| `integrations.googleEmail` | E-Mail für ALLE Dienste |
| `integrations.googleDisplayName` | Anzeigename |
| `integrations.googlePhotoUrl` | Profilbild |
| `integrations.googleClientIdWeb` | OAuth Client ID |
| `integrations.googleClientSecret` | OAuth Secret |

### Pflicht-Ablauf
```
1. flutterclaw.json lesen
2. integrations.googleEmail extrahieren
3. Erst dann API-Aufruf ausführen
4. NIEMALS ohne verifizierten Wert fortfahren
```

### Wenn flutterclaw.json fehlt
> "Keine verifizierte Benutzeridentität gefunden.
> Bitte zuerst mit Google anmelden."
> → Aktion abbrechen, NICHT raten.

---

## 2. SICHERHEIT – Gilt für alle schreibenden Aktionen

### Lesende Aktionen (keine Bestätigung nötig)
✅ E-Mails lesen / suchen / anzeigen
✅ Kalender anzeigen
✅ Drive-Dateien auflisten
✅ Kontakte anzeigen
✅ Tasks anzeigen
✅ Chat-Nachrichten lesen

### Destruktive Aktionen (IMMER Bestätigung einholen)
| Aktion | Risiko |
|--------|--------|
| E-Mail löschen / archivieren | ⚠️ |
| E-Mail senden | ⚠️ |
| Kalender-Eintrag löschen / ändern | ⚠️ |
| Drive-Datei löschen / verschieben | ⚠️ |
| Chat-Nachricht senden | ⚠️ |
| Bulk-Operationen (>5 Elemente) | 🚨 |

### Bestätigungs-Ablauf
```
1. Zeige Zusammenfassung was ausgeführt wird
2. Zeige betroffenen Account (googleEmail)
3. Warte auf: "ja" / "ok" / "bestätigt"
4. Führe erst dann aus
```

Beispiel:
> "Ich werde folgendes ausführen:
> 🗑️ 3 E-Mails löschen von newsletter@example.com
> Account: pz@gmail.com
> Bestätigen mit: ja / nein"

### Bulk-Regel (mehr als 5 Elemente)
Zusätzlich zur normalen Bestätigung:
- Genaue Anzahl nennen
- 3 Beispiele zeigen
- Explizite Bestätigung verlangen: `"ja, alle [N] löschen"`

### Nach jeder Aktion
> "✅ Erledigt: [Beschreibung] (pz@gmail.com)"
> oder
> "❌ Abgebrochen: Keine Änderungen vorgenommen"

---

## 3. GMAIL

### Basis-URL
```
https://gmail.googleapis.com/gmail/v1/users/me
```
→ `userId` ist IMMER `me` – niemals die E-Mail direkt einsetzen

### Wichtige Endpoints

```
# Inbox abrufen
GET /messages?labelIds=INBOX&maxResults=20

# E-Mail lesen
GET /messages/{messageId}

# E-Mail suchen
GET /messages?q=from:sender@example.com

# E-Mail senden
POST /messages/send

# E-Mail löschen (Papierkorb)
POST /messages/{messageId}/trash

# E-Mail permanent löschen
DELETE /messages/{messageId}

# Labels verwalten
GET /labels
POST /messages/{messageId}/modify
```

### Nutzer-Anfragen erkennen
- "zeig meine Inbox" → GET /messages?labelIds=INBOX
- "suche Mails von X" → GET /messages?q=from:X
- "lösche diese Mail" → Bestätigung → trash oder delete
- "sende Antwort" → Bestätigung → POST /messages/send
- "markiere als gelesen" → modify labels

---

## 4. GOOGLE CALENDAR

### Basis-URL
```
https://www.googleapis.com/calendar/v3
```

### calendarId
→ IMMER `integrations.googleEmail` aus flutterclaw.json
→ NIEMALS `primary` durch eigene E-Mail ersetzen

### Wichtige Endpoints

```
# Kalender-Liste abrufen
GET /calendars/{calendarId}

# Termine abrufen (heute / Zeitraum)
GET /calendars/{calendarId}/events
  ?timeMin=2026-02-23T00:00:00Z
  &timeMax=2026-02-23T23:59:59Z
  &singleEvents=true
  &orderBy=startTime

# Termin erstellen
POST /calendars/{calendarId}/events

# Termin ändern
PATCH /calendars/{calendarId}/events/{eventId}

# Termin löschen
DELETE /calendars/{calendarId}/events/{eventId}
```

### Nutzer-Anfragen erkennen
- "was habe ich heute" → events mit timeMin/timeMax für heute
- "nächste Woche" → events für nächste 7 Tage
- "erstelle Termin" → Bestätigung → POST events
- "lösche Termin" → Bestätigung → DELETE events
- "verschiebe Termin" → Bestätigung → PATCH events

### Datum/Zeit immer in ISO 8601
```
2026-02-23T14:00:00+01:00
```

---

## 5. GOOGLE DRIVE

### Basis-URL
```
https://www.googleapis.com/drive/v3
```

### Wichtige Endpoints

```
# Dateien auflisten
GET /files
  ?q='root' in parents
  &fields=files(id,name,mimeType,modifiedTime,size)

# Datei suchen
GET /files?q=name contains 'Bericht'

# Datei herunterladen
GET /files/{fileId}?alt=media

# Datei hochladen
POST https://www.googleapis.com/upload/drive/v3/files
  ?uploadType=multipart

# Datei löschen
DELETE /files/{fileId}

# Datei verschieben
PATCH /files/{fileId}
  ?addParents={folderId}
  &removeParents={oldParentId}

# Freigabe verwalten
POST /files/{fileId}/permissions
```

### MIME-Types
| Typ | MIME |
|-----|------|
| Google Docs | application/vnd.google-apps.document |
| Google Sheets | application/vnd.google-apps.spreadsheet |
| Google Slides | application/vnd.google-apps.presentation |
| Ordner | application/vnd.google-apps.folder |
| PDF | application/pdf |

### Nutzer-Anfragen erkennen
- "zeig meine Dateien" → GET /files
- "suche Datei X" → GET /files?q=name contains 'X'
- "lösche Datei" → Bestätigung → DELETE /files/{id}
- "teile mit X" → Bestätigung → POST /permissions

---

## 6. GOOGLE CHAT

### Basis-URL
```
https://chat.googleapis.com/v1
```

### Wichtige Endpoints

```
# Spaces (Räume) auflisten
GET /spaces

# Nachrichten in einem Space abrufen
GET /spaces/{spaceName}/messages

# Nachricht senden
POST /spaces/{spaceName}/messages

# Nachricht löschen
DELETE /spaces/{spaceName}/messages/{messageName}

# Direkte Nachricht (DM) erstellen
POST /spaces:setup
```

### Nutzer-Anfragen erkennen
- "zeig meine Chats" → GET /spaces
- "Nachrichten in [Raum]" → GET /spaces/{name}/messages
- "sende Nachricht an X" → Bestätigung → POST /messages
- "lösche Nachricht" → Bestätigung → DELETE /messages

---

## 7. GOOGLE MEET

### Meet wird über Calendar verwaltet
Meetings werden als Calendar-Events mit Meet-Link erstellt:

```
POST /calendars/{calendarId}/events
{
  "summary": "Meeting Titel",
  "start": {"dateTime": "2026-02-24T10:00:00+01:00"},
  "end": {"dateTime": "2026-02-24T11:00:00+01:00"},
  "conferenceData": {
    "createRequest": {
      "requestId": "unique-id",
      "conferenceSolutionKey": {"type": "hangoutsMeet"}
    }
  }
}
```

Parameter: `conferenceDataVersion=1`

### Nutzer-Anfragen erkennen
- "erstelle Meeting" → Bestätigung → Calendar Event mit conferenceData
- "Meet-Link für Termin" → Calendar Event abrufen → conferenceData.entryPoints

---

## 8. GOOGLE CONTACTS

### Basis-URL
```
https://people.googleapis.com/v1
```

### Wichtige Endpoints

```
# Kontakte abrufen
GET /people/me/connections
  ?personFields=names,emailAddresses,phoneNumbers

# Kontakt suchen
GET /people:searchContacts?query=Max

# Kontakt erstellen
POST /people:createContact

# Kontakt aktualisieren
PATCH /people/{resourceName}:updateContact

# Kontakt löschen
DELETE /people/{resourceName}:deleteContact
```

---

## 9. GOOGLE TASKS

### Basis-URL
```
https://tasks.googleapis.com/tasks/v1
```

### Wichtige Endpoints

```
# Task-Listen abrufen
GET /users/@me/lists

# Tasks abrufen
GET /lists/{tasklistId}/tasks

# Task erstellen
POST /lists/{tasklistId}/tasks

# Task erledigen / aktualisieren
PATCH /lists/{tasklistId}/tasks/{taskId}

# Task löschen
DELETE /lists/{tasklistId}/tasks/{taskId}
```

---

## 10. OAUTH SCOPES

Stelle sicher dass beim Login die richtigen Scopes angefragt werden:

```dart
// Flutter – alle benötigten Scopes
final scopes = [
  'https://www.googleapis.com/auth/gmail.modify',
  'https://www.googleapis.com/auth/calendar',
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/chat.messages',
  'https://www.googleapis.com/auth/contacts',
  'https://www.googleapis.com/auth/tasks',
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
];
```

---

## 11. FEHLERBEHANDLUNG

| HTTP Status | Bedeutung | Reaktion |
|---|---|---|
| 400 | Ungültige Anfrage | Parameter prüfen, Nutzer informieren |
| 401 | Nicht authentifiziert | Token erneuern, neu anmelden |
| 403 | Keine Berechtigung | Scope fehlt, Nutzer informieren |
| 404 | Nicht gefunden | Nutzer informieren |
| 429 | Rate Limit | Kurz warten, erneut versuchen |
| 500 | Server-Fehler | Erneut versuchen, Nutzer informieren |

Bei Fehler NIEMALS automatisch wiederholen – Nutzer zuerst informieren.

---

## 12. ALLGEMEINE REGELN

- Identität IMMER aus `flutterclaw.json → integrations.googleEmail`
- Destruktive Aktionen IMMER mit Bestätigung
- Bulk-Operationen (>5) mit expliziter Bestätigung
- Fehler klar kommunizieren, nie stillschweigend ignorieren
- Nach jeder Aktion kurze Erfolgs- oder Fehlermeldung ausgeben

> ⚠️ *Dieser Skill greift auf persönliche Google-Daten zu.
> Alle Aktionen werden im Namen von `integrations.googleEmail` ausgeführt.*
